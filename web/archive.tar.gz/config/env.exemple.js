module.exports = {
    prod: false,
    filemoon_API: "",
    port: 1522,
    url: "http://localhost:1522",
    db_path: "data/database.sqlite",
    video_path: "./video/",
}