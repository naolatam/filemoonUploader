module.exports = {
    prod: false,
    filemoon_API: "15216rzwuvdaveatzru7d",
    port: 1522,
    url: "http://localhost:1522",
    db_path: "data/database.sqlite",
    video_path: "./videos/",
}